

public class Entry {
        public string _question= "";
        public string _answer= "";
        public string _dateText = "";
      
        public void Display()
    {
        Console.WriteLine($"{_question} ({_answer}) {_dateText}");
    }
      }


   