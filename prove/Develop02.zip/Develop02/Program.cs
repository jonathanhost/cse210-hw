using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Journal Program!");
        string option = "0";
        while (option != "5") 
    {
        Console.WriteLine("Please select one of the followeing choices:");
        Console.WriteLine("1. Write \n2.Display \n3. Load \n4. Save \n5. Quit \nWhat would you like to do? ");
        option = Console.ReadLine();
        Journal _journal = new Journal();
        switch(option) 
            {
            case "1":
                PromptGenerator _prompt = new PromptGenerator();
                Entry _entry = new Entry();
                _entry._question = _prompt.Display();
                Console.WriteLine(_entry._question);
                _entry._answer = Console.ReadLine();
                DateTime theCurrentTime = DateTime.Now;
                _entry._dateText = theCurrentTime.ToShortDateString();
                _journal.AddEntry(_entry);
                _journal._entries.Add(_entry);

                break;
            case "2":
                 foreach (Entry entry in _journal._entries)
                    {
                        Console.WriteLine("inside");
                        // This calls the Display method on each job
                        entry.Display();
                    }
                break;
            case "3":
                // code block
                break;
            case "4":
                // code block
                break;
             case "5":
                Console.WriteLine("Bye Bye");
                break;
            default:
                // code block
                break;
                }
    }
    }
}


